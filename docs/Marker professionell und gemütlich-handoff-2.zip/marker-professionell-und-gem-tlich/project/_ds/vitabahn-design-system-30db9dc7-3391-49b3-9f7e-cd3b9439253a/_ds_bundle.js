/* @ds-bundle: {"format":3,"namespace":"VitaBahnDesignSystem_30db9d","components":[],"sourceHashes":{},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.VitaBahnDesignSystem_30db9d = window.VitaBahnDesignSystem_30db9d || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

})();
